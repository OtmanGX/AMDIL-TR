package com.example.systemeamdiltr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.res.ColorStateList;
import android.os.Bundle;

import android.os.Handler;

import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.physicaloid.lib.Physicaloid;
import com.physicaloid.lib.usb.driver.uart.ReadLisener;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;


import static java.util.Calendar.getInstance;

public class MainActivity extends AppCompatActivity implements tempDialog.ExampleDialogListener {

    //Connection Declaration.
    private String dataStock="";
    private Physicaloid mPhysicaloid;
    private byte[] buf ;
    private Thread thread;
    private Handler mHandler = new Handler();
    private Button connect;
    public static int tP ;
    private Button btnClose;

    //Declaration Charts
    private LineChart mChart;
    private LineChart mChart2;
    private LineChart mChart3;
    private ArrayList<String> timeArraylist = new ArrayList<String>();

    public static ArrayList<String> timeArraylist2 = new ArrayList<String>();
    public static ArrayList<Integer> tempArraylist = new ArrayList<Integer>();
    public static ArrayList<Integer> pressArraylist = new ArrayList<Integer>();


    public static ArrayList<Integer> dayAVGlist = new ArrayList<Integer>();
    private ArrayList<String> daysAVGName = new ArrayList<String>();
    public static ArrayList<Integer> monthAVGlist = new ArrayList<Integer>();
    public static ArrayList<Integer> helplist = new ArrayList<Integer>();
    private ArrayList<String> monthsAVGName = new ArrayList<String>();


    //***************************************************************************************


    public static ArrayList<Integer> lastMonthList = new ArrayList<Integer>();
    public static ArrayList<String> lastMonthListX = new ArrayList<String>();

    public static ArrayList<Integer> lastYearList = new ArrayList<Integer>();
    public static ArrayList<String> lastYearListX = new ArrayList<String>();


    public static ArrayList<Integer> lastMonthListP = new ArrayList<Integer>();
    public static ArrayList<String> lastMonthListXP = new ArrayList<String>();

    public static ArrayList<Integer> lastYearListP = new ArrayList<Integer>();
    public static ArrayList<String> lastYearListXP = new ArrayList<String>();


    int x=0,y=0 ;
    int x2=0,y2=0 ;
    int x3=0,y3=0 ;

    // les vaiables des modes
    Boolean mode;
    int connexion = 0;

    Button mRec;
    Button mEmet;








    //Declaration des champ
    TextView tempTV,
            presTV,
            dateTV;

    TextView redImgMax,
            greenImgMax,
            orangImgMax,
            sImgMax,
            redImgmin,
            greenImgmin,
            orangImgmin,
            sImgmin;

    TextView redImgMaxP,
           greenImgMaxP,
           orangImgMaxP,
            sImgMaxP,
             redImgminP,
           greenImgminP,
           orangImgminP,
            sImgminP;

    float   t5Value = 25,
            t4Value = 24,
            t3Value =23,
            t2Value =22,
            t1Value =21;

    float   p5Value = 5,
            p4Value = 4,
            p3Value =3,
            p2Value =2,
            p1Value =1;


    ImageView redImg,
             sImg,
            greenImg,
            orangeImg;

    ImageView redImgP,
             sImgP,
            greenImgP,
            orangeImgP;


    Button updatBtn ;

    Button pConfig;
    Button tConfig;


// on creat ---------------------------------------------------------------------------------------------


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    // get Last Month/year Data

        DatabaseAccess databaseAccess=DatabaseAccess.getInstance(getApplicationContext());
        databaseAccess.open();
        int monthT = databaseAccess.getMonthTData();
        int yearT = databaseAccess.getYearTData();
        int monthP = databaseAccess.getMonthPData();
        int yearP = databaseAccess.getYearPData();

   // Connection Declaration;
        mPhysicaloid = new Physicaloid(this);
        mPhysicaloid.setBaudrate(9600);
        connect=(Button) findViewById(R.id.connect_id);

   // Declaration des Champs
        tempTV =(TextView) findViewById(R.id.tempTV);
        presTV =(TextView) findViewById(R.id.pressTV);
        dateTV =(TextView) findViewById(R.id.dateTV);

        redImgMax  = (TextView) findViewById(R.id.redMAXTVT) ;
        greenImgMax= (TextView) findViewById(R.id.greenMAXTVT) ;
        orangImgMax= (TextView) findViewById(R.id.orangeMAXTVT) ;
        sImgMax = (TextView) findViewById(R.id.bleuMAXTVT) ;
        redImgmin  = (TextView) findViewById(R.id.redminTVT) ;
        greenImgmin= (TextView) findViewById(R.id.greenminTVT) ;
        orangImgmin= (TextView) findViewById(R.id.orangeminTVT) ;
        sImgmin=  (TextView) findViewById(R.id.bleuminTVT) ;

        redImgMaxP  = (TextView) findViewById(R.id.redMAXTVP) ;
        greenImgMaxP= (TextView) findViewById(R.id.greenMAXTVP) ;
        orangImgMaxP= (TextView) findViewById(R.id.orangeMAXTVP) ;
        sImgMaxP = (TextView) findViewById(R.id.bleuMAXTVP) ;
        redImgminP  = (TextView) findViewById(R.id.redeminTVP) ;
        greenImgminP= (TextView) findViewById(R.id.greenminTVP) ;
        orangImgminP= (TextView) findViewById(R.id.orangeminTVP) ;
        sImgminP=  (TextView) findViewById(R.id.bleuminTVP) ;


        redImg =(ImageView) findViewById(R.id.redIMGid) ;
        orangeImg=(ImageView) findViewById(R.id.orangeIMGid) ;
        greenImg=(ImageView) findViewById(R.id.greenIMGid) ;
        sImg=(ImageView) findViewById(R.id.sIMGid) ;


        redImgP =(ImageView) findViewById(R.id.redIMGidP) ;
        orangeImgP=(ImageView) findViewById(R.id.orangeIMGidP) ;
        greenImgP=(ImageView) findViewById(R.id.greenIMGidP) ;
        sImgP=(ImageView) findViewById(R.id.sIMGidP) ;


        mRec =(Button) findViewById(R.id.recbtn);
        mEmet = (Button) findViewById(R.id.emetrec);

    //Setup de view

    dateTV.setText(toDay());


    // update les valeurs
        updatBtn =(Button) findViewById(R.id.updatBtn);
        updatBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                updateValues();
            }
        });



    // les préferences
        setUp();
        updateValues();


     //Déclaration des chart
        //Chart1
        mChart = (LineChart) findViewById(R.id.chart1);
        mChart.animateXY(2000, 2000);
        mChart.invalidate();
        LineData data = new LineData();
        mChart.setData(data);
        YAxis rightAxis = mChart.getAxisRight();
        rightAxis.setEnabled(true);
        //Chart2
        mChart2 = (LineChart) findViewById(R.id.chart2);
        mChart2.animateXY(2000, 2000);
        mChart2.invalidate();
        LineData data2 = new LineData();
        mChart2.setData(data2);
        YAxis rightAxis2 = mChart2.getAxisRight();
        rightAxis2.setEnabled(true);
        //Chart2
        mChart3 = (LineChart) findViewById(R.id.chart3);
        mChart3.animateXY(2000, 2000);
        mChart3.invalidate();
        LineData data3 = new LineData();
        mChart3.setData(data3);
        YAxis rightAxis3 = mChart3.getAxisRight();
        rightAxis3.setEnabled(true);





        for(int i=0;i<lastYearList.size();i++){

            addDatatoChartYear(lastYearList.get(i),lastYearListP.get(i));
        }
        for(int i=0;i<lastMonthList.size();i++){

            addDatatoChartMonth(lastMonthList.get(i),lastMonthListP.get(i));
        }


   //  Etablir la connection

        connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                connexion++;
                if(connexion<3){


                    if(mPhysicaloid.open()) {
                        if(connexion==2){
                            connect.setText("Fermer la connexion");
                            connect.setTextColor(getApplication().getResources().getColor(R.color.GreenAccent));
                        }

                        mPhysicaloid.addReadListener(new ReadLisener() {
                            @Override
                            public void onRead(int size) {

                                buf = new byte[size];

                                mPhysicaloid.read(buf, size);


                                for(int i=0;i<size;i++)
                                {
                                    char a=(char)buf[i];

                                    dataStock += a;
                                    if(a=='F' )
                                    {

                                        String data[] = dataStock.split(";",-2);
                                        if(data[0].indexOf("S")>1){
                                            affectation(data[1],data[2],data[3]) ;

                                        }
                                        dataStock="";
                                    }
                                }

                            }
                        });
                    } else {
                        Toast.makeText(getApplicationContext(), "Cannot open", Toast.LENGTH_LONG).show();
                    }

                }


                if(connexion==3){
                    if(mPhysicaloid.close()) {
                        mPhysicaloid.clearReadListener();

                    }
                    connect.setText("Etablir la connexion");
                    connect.setTextColor(getApplication().getResources().getColor(R.color.primaryLightColor));
                    connexion=1;
                }
            }
        });

        // Température Configuration
        pConfig = (Button) findViewById(R.id.configPbtn) ;
        tConfig = (Button) findViewById(R.id.configTbtn) ;
        tConfig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tP = 1;
                openDialog();
            }
        });
        pConfig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tP = 2;
                openDialog();
            }
        });
    }

    //Fonction d'affectation
    private void affectation(final String temp, final String press, final String msg
                             ) {
        // les afficheur des valeurs
        final Float tempF=(Float.parseFloat(temp))/100;
        final Float pressF=(Float.parseFloat(press))/100;

        tvAppend(tempTV,(Float.toString(tempF))+" °C");
        tvAppend(presTV,(Float.toString(pressF))+" Bar");


        // la gestion de signalisation

        mHandler.post(new Runnable() {
            @Override
            public void run() {


                if (tryParseInt(temp) && tryParseInt(press) ) {

                    onSavedata(tempF,pressF);
                    signalisation(tempF,pressF);
                    addDataToChart(tempF,pressF);
                    addDatatoChartMonthNew(tempF, pressF);
                    showMode(Integer.parseInt(msg));
                }


            }
        });


    }

    //Text handler
    private void tvAppend(TextView tv, final CharSequence text) {
        final TextView ftv = tv;
        final CharSequence ftext = text;
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                ftv.setText(text);
            }
        });
    }


    private void updateValues() {
        String str = getConfiguration();	//get text from EditText
        if(str.length()>0) {
            byte[] buf = str.getBytes();	//convert string to byte array
            mPhysicaloid.write(buf, buf.length);	//write data to arduino
        }


    }
    private void signalisation(float temp, float press) {
    //  Temperature signalisation
        //  Red signalisation
        if (temp>= t2Value){
            redImg.setImageResource(R.drawable.ledred);
        }
        if (temp < t2Value){
            redImg.setImageResource(R.drawable.ledoff);
        }
         //  Orange signalisation
        if (temp>= t1Value && temp< t2Value ){
            orangeImg.setImageResource(R.drawable.ledorange);
        } else orangeImg.setImageResource(R.drawable.ledoff);

        //  Green signalisation
        if (temp< t1Value){
            greenImg.setImageResource(R.drawable.ledgreen);
        } else greenImg.setImageResource(R.drawable.ledoff);

        //  Bleu signalisation
        if (temp>= t3Value){
            sImg.setImageResource(R.drawable.alarmon);
            vibration();
        }
        if (temp < t3Value){
            sImg.setImageResource(R.drawable.alarmoff);
        }


    //  Pression signalisation
        //  Red signalisation
        if (press>= p2Value){
            redImgP.setImageResource(R.drawable.ledred);
        }
        if (press < p2Value){
            redImgP.setImageResource(R.drawable.ledoff);
        }
        //  Orange signalisation
        if (press>= p1Value && press< p2Value ){
            orangeImgP.setImageResource(R.drawable.ledorange);
        } else orangeImgP.setImageResource(R.drawable.ledoff);

        //  Green signalisation
        if (press< p1Value){
            greenImgP.setImageResource(R.drawable.ledgreen);
        } else greenImgP.setImageResource(R.drawable.ledoff);

        //  Bleu signalisation
        if (press>= p3Value){
            sImgP.setImageResource(R.drawable.alarmon);
            vibration();
        }
        if (press< p3Value){
            sImgP.setImageResource(R.drawable.alarmoff);
        }
    }


    private void setUp() {

        redImgMax.setText("");
        orangImgMax.setText("< "+ Float.toString(t3Value)+ "°C");
        greenImgMax.setText("< "+ Float.toString(t2Value)+ "°C");
        sImgMax.setText("< "+ Float.toString(t1Value)+ "°C");
        redImgmin.setText(Float.toString(t3Value)+ "°C <");
        greenImgmin.setText(Float.toString(t1Value)+ "°C <");
        orangImgmin.setText(Float.toString(t2Value)+ "°C <");
        sImgmin.setText("");

        redImgMaxP.setText("");
        orangImgMaxP.setText("< "+ Float.toString(p3Value)+ "bar");
        greenImgMaxP.setText("< "+Float.toString(p2Value)+ "bar");
        sImgMaxP.setText("< "+ Float.toString(p1Value)+ "bar");
        redImgminP.setText(Float.toString(p3Value)+ "bar <");
        greenImgminP.setText(Float.toString(p1Value)+ "bar <");
        orangImgminP.setText(Float.toString(p2Value)+ "bar <");
        sImgminP.setText("");

    }

    // les fonction des chart
    private LineDataSet createSet(String DynamiqueData,int color) {

        LineDataSet set = new LineDataSet(null, DynamiqueData);
        set.setAxisDependency(YAxis.AxisDependency.LEFT);

        set.setLineWidth(3f);
        set.setColor(color);
        set.setCircleColor(color);
        return set;
    }

    private LineDataSet createSet2(String DynamiqueData,int color) {

        LineDataSet set = new LineDataSet(null, DynamiqueData);
        set.setAxisDependency(YAxis.AxisDependency.LEFT);
        set.setLineWidth(1f);
        set.setColor(color);
        set.setCircleColor(color);
        set.setHighlightEnabled(false);
        set.setDrawValues(false);
        set.setDrawCircles(false);


        return set;
    }


    private void addDataToChart(float tempIn, float pressIn) {

        LineData data = mChart.getData();
        if (data != null) {

            ILineDataSet setPress = data.getDataSetByIndex(0);
            ILineDataSet setTemp = data.getDataSetByIndex(1);


            // setTension.addEntry(...); // can be called as well

            if (setPress == null) {
                setPress = createSet("Pression",getResources().getColor(R.color.colorPrimary));
                data.addDataSet(setPress);

            }
            if (setTemp == null) {
                setTemp = createSet("Température",getResources().getColor(R.color.colorAccent));
                data.addDataSet(setTemp);
            }


            data.addEntry(new Entry(x, (float) tempIn), 0);
            data.addEntry(new Entry(x, (float) pressIn), 1);

            XAxis xl = mChart.getXAxis();
            addCurrentTime();
            final Date currentTime = getInstance().getTime();
            xl.setTextColor(getResources().getColor(R.color.colorPrimary));
            xl.setDrawGridLines(true);
            xl.setAvoidFirstLastClipping(true);
            xl.setEnabled(true);
            xl.setValueFormatter(new IAxisValueFormatter() {
                @Override
                public String getFormattedValue(float value, AxisBase axis) {
                    return timeArraylist.get((int) value); // xVal is a string array
                }


            });

            data.notifyDataChanged();
            x++;
            y++;

            // let the chart know it's data has changed
            mChart.notifyDataSetChanged();

            // limit the number of visible entries
            mChart.setVisibleXRangeMaximum(8);
            // mChart.setVisibleYRange(30, AxisDependency.LEFT);

            // move to the latest entry
            mChart.moveViewToX(data.getEntryCount());

        }

    }

    private void addDatatoChartMonth(float temp, float press) {

        LineData data = mChart2.getData();
        if (data != null) {

            ILineDataSet setPress = data.getDataSetByIndex(0);
            ILineDataSet setTemp = data.getDataSetByIndex(0);


            // setTension.addEntry(...); // can be called as well

            if (setTemp == null) {
                setTemp = createSet2("Température",getResources().getColor(R.color.colorPrimary));
                data.addDataSet(setTemp);

            }
            if (setPress == null) {
                setPress = createSet2("Pression",getResources().getColor(R.color.colorAccent));
                data.addDataSet(setPress);
            }


            data.addEntry(new Entry(x2, (float) temp), 0);
            data.addEntry(new Entry(x2, (float) press), 1);
            XAxis xl = mChart2.getXAxis();



            xl.setTextColor(getResources().getColor(R.color.colorPrimary));
            xl.setDrawGridLines(true);
            xl.setAvoidFirstLastClipping(true);
            xl.setEnabled(true);
            xl.setValueFormatter(new IAxisValueFormatter() {
                @Override
                public String getFormattedValue(float value, AxisBase axis) {
                    return lastMonthListX.get((int) value); // xVal is a string array
                }


            });

            data.notifyDataChanged();
            x2++;
            y++;

            // let the chart know it's data has changed
            mChart2.notifyDataSetChanged();

            // move to the latest entry
            mChart2.moveViewToX(data.getEntryCount());

        }

    }

    private void addDatatoChartMonthNew(float temp, float press) {

        LineData data = mChart2.getData();
        if (data != null) {

            ILineDataSet setPress = data.getDataSetByIndex(0);
            ILineDataSet setTemp = data.getDataSetByIndex(0);


            // setTension.addEntry(...); // can be called as well

            if (setTemp == null) {
                setTemp = createSet2("Température",getResources().getColor(R.color.colorPrimary));
                data.addDataSet(setTemp);

            }
            if (setPress == null) {
                setPress = createSet2("Pression",getResources().getColor(R.color.colorAccent));
                data.addDataSet(setPress);
            }


            data.addEntry(new Entry(x2, (float) temp), 0);
            data.addEntry(new Entry(x2, (float) press), 1);
            XAxis xl = mChart2.getXAxis();

            lastMonthListX.add(getCurrentTime());

            xl.setTextColor(getResources().getColor(R.color.colorPrimary));
            xl.setDrawGridLines(true);
            xl.setAvoidFirstLastClipping(true);
            xl.setEnabled(true);
            xl.setValueFormatter(new IAxisValueFormatter() {
                @Override
                public String getFormattedValue(float value, AxisBase axis) {
                    return lastMonthListX.get((int) value); // xVal is a string array
                }


            });

            data.notifyDataChanged();
            x2++;
            y++;

            // let the chart know it's data has changed
            mChart2.notifyDataSetChanged();

            // move to the latest entry
            mChart2.moveViewToX(data.getEntryCount());

        }

    }




    private void addDatatoChartYear(float temp, float press) {

        LineData data = mChart3.getData();
        if (data != null) {

            ILineDataSet setPress = data.getDataSetByIndex(0);
            ILineDataSet setTemp = data.getDataSetByIndex(0);


            // setTension.addEntry(...); // can be called as well

            if (setTemp == null) {
                setTemp = createSet2("Température",getResources().getColor(R.color.colorPrimary));
                data.addDataSet(setTemp);

            }
            if (setPress == null) {
                setPress = createSet2("Pression",getResources().getColor(R.color.colorAccent));
                data.addDataSet(setPress);
            }


            data.addEntry(new Entry(x3, (float) temp), 0);
            data.addEntry(new Entry(x3, (float) press), 1);
            XAxis xl = mChart3.getXAxis();

            final Date currentTime = getInstance().getTime();

            xl.setTextColor(getResources().getColor(R.color.colorPrimary));
            xl.setDrawGridLines(true);
            xl.setAvoidFirstLastClipping(true);
            xl.setEnabled(true);
            xl.setValueFormatter(new IAxisValueFormatter() {
                @Override
                public String getFormattedValue(float value, AxisBase axis) {
                    return lastYearListX.get((int) value); // xVal is a string array
                }


            });
            data.notifyDataChanged();
            x3++;
            y++;

            // let the chart know it's data has changed
            mChart3.notifyDataSetChanged();
            // move to the latest entry
            mChart3.moveViewToX(data.getEntryCount());

        }

    }









    public  void addCurrentTime() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("HH:mm:ss");
        Date now = new Date();
        String strDate = sdfDate.format(now);
        timeArraylist.add(strDate) ;


    }
    public  String getCurrentTime() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("HH:mm:ss");
        Date now = new Date();
        String strDate = sdfDate.format(now);


        return strDate ;
    }


    // fonction pour ouvrir le dialog
    public void openDialog() {
        tempDialog tempDialog = new tempDialog();
        tempDialog.show(getSupportFragmentManager(), "example dialog");
    }

    @Override
    public void applyTexts(String t1, String t2, String t3, String t4, String t5) {

     if(tP==1){
         t5Value = Integer.parseInt(t5);
         t4Value = Integer.parseInt(t4);
         t3Value= Integer.parseInt(t3);
         t2Value= Integer.parseInt(t2);
         t1Value= Integer.parseInt(t1);
     }
        if(tP==2){
            p5Value = Integer.parseInt(t5);
            p4Value = Integer.parseInt(t4);
            p3Value= Integer.parseInt(t3);
            p2Value= Integer.parseInt(t2);
            p1Value= Integer.parseInt(t1);
        }


        setUp();
    }



    // add data -----------------------------------------------------------------------

    public void onSavedata(float temp,float press){
        DatabaseAccess databaseAccess=DatabaseAccess.getInstance(getApplicationContext());
        databaseAccess.open();
        String date=getDate();
        String dateymd = getdateydm();
        int mois = Integer.parseInt(getMonth());
        int day = Integer.parseInt(getDay());
        databaseAccess.addData(date,dateymd,mois,day,temp,press);
        databaseAccess.close();
    }







    public String toDay(){
        String toDay;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        Date date = new Date();
        toDay= dateFormat.format(date);

        return toDay;
    }

    public String getDay(){
        String mDate;
        String theDay;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        Date date = new Date();
        mDate= dateFormat.format(date);
        String[] parts = mDate.split("/");
        theDay = parts[2];
        return theDay;
    }

    public String getMonth(){
        String mDate;
        String theMonth;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        Date date = new Date();
        mDate= dateFormat.format(date);
        String[] parts = mDate.split("/");
        theMonth = parts[1];
        return theMonth;
    }
    public String getDate(){

        String theDate;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        theDate= dateFormat.format(date);
        return theDate;
    }
    public String getdateydm(){
        String output;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        Date date = new Date();
        output= dateFormat.format(date);
        return output;
    }




    // eviter les erreurs de conversion
    boolean tryParseInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    //    --------------------------

    public String  getConfiguration(){
        String text ;
        float a=t1Value*100;
        float z=t1Value*100;
        float k=t1Value*100;
        text = a +"*"+z+"*"+k ;
        return text ;
    }

    public void showMode(int t1){

        if(t1==0){
           mRec.setTextColor(getApplication().getResources().getColor(R.color.GreenAccent));
           mRec.setBackgroundTintList(ColorStateList.valueOf(getApplication().getResources().getColor(R.color.primaryLightColor)));
           mEmet.setTextColor(getApplication().getResources().getColor(R.color.primaryLightColor));
           mEmet.setBackgroundTintList(ColorStateList.valueOf(getApplication().getResources().getColor(R.color.colorAccent)));

        }else {
            mEmet.setTextColor(getApplication().getResources().getColor(R.color.GreenAccent));
            mEmet.setBackgroundTintList(ColorStateList.valueOf(getApplication().getResources().getColor(R.color.primaryLightColor)));
            mRec.setTextColor(getApplication().getResources().getColor(R.color.primaryLightColor));
            mRec.setBackgroundTintList(ColorStateList.valueOf(getApplication().getResources().getColor(R.color.colorAccent)));

        }


    }


    public void vibration(){

        // Get instance of Vibrator from current Context
        Vibrator v = (Vibrator) getSystemService(getApplicationContext().VIBRATOR_SERVICE);

        long[] pattern = {0, 500, 100};

        v.vibrate(pattern, 0);
    }

























}
